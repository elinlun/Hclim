## Write flags in dataresqc format for monthly data

library(dataresqc)

inpath <- "./"
outpath <- "/scratch3/PALAEO-RA/DataRescue/Projects/Global-Datasets/5_QCed/SRM/"
variable <- "p"

x <- read.table(paste0(inpath,"qc_monthly.txt"), stringsAsFactors=FALSE, header=TRUE)

for (id in unique(x$id)) {
  outname <- paste0("qc_", id, "_", variable, "_monthly.txt")
  y <- x[x$id==id, ]
  out <- data.frame(Var=rep(variable,nrow(y)),
                    Year=y$year,
                    Month=y$month,
                    Day=rep("",nrow(y)),
                    Hour=rep("",nrow(y)),
                    Minute=rep("",nrow(y)),
                    Value=y$value,
                    Test=rep("outlier",nrow(y)),
                    stringsAsFactors=FALSE)
  write.table(out, file=paste0(outpath,outname), row.names=FALSE, quote=FALSE, sep="\t")
}
